package br.com.docket.dao;

import br.com.docket.model.Cartorio;

public interface CartorioDAO extends GenericDAO<Cartorio, Integer>{

}
